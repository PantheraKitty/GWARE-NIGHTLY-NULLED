package io.netty.handler.codec.socksx.v4;

import io.netty.handler.codec.socksx.SocksMessage;

public interface Socks4Message extends SocksMessage {
}
