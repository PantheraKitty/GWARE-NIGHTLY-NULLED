package io.netty.handler.codec.socks;

public enum SocksMessageType {
   REQUEST,
   RESPONSE,
   UNKNOWN;
}
