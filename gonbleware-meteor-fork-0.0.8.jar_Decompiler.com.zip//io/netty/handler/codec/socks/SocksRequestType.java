package io.netty.handler.codec.socks;

public enum SocksRequestType {
   INIT,
   AUTH,
   CMD,
   UNKNOWN;
}
