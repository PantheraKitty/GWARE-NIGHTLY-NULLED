package meteordevelopment.meteorclient.mixininterface;

public interface IBakedQuad {
   float meteor$getX(int var1);

   float meteor$getY(int var1);

   float meteor$getZ(int var1);
}
