package meteordevelopment.meteorclient.mixininterface;

import net.minecraft.class_1297;
import net.minecraft.class_2824.class_5907;

public interface IPlayerInteractEntityC2SPacket {
   class_5907 getType();

   class_1297 getEntity();
}
