package meteordevelopment.meteorclient.mixininterface;

import net.minecraft.class_1297;
import net.minecraft.class_2960;

public interface IEntityRenderer {
   class_2960 getTextureInterface(class_1297 var1);
}
