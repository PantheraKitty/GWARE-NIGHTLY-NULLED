package meteordevelopment.meteorclient.mixininterface;

import net.minecraft.class_243;

public interface IItemEntity {
   class_243 getRotation();

   void setRotation(class_243 var1);
}
