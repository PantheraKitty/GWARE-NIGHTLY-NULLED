package meteordevelopment.meteorclient.mixininterface;

import net.minecraft.class_1799;

public interface IAbstractFurnaceScreenHandler {
   boolean isItemSmeltable(class_1799 var1);
}
