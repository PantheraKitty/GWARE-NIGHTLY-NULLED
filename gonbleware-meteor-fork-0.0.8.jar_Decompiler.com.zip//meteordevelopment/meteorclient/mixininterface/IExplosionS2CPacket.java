package meteordevelopment.meteorclient.mixininterface;

public interface IExplosionS2CPacket {
   void setVelocityX(float var1);

   void setVelocityY(float var1);

   void setVelocityZ(float var1);
}
