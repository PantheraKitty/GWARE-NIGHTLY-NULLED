package meteordevelopment.meteorclient.mixininterface;

import com.mojang.authlib.GameProfile;

public interface IMessageHandler {
   GameProfile meteor$getSender();
}
