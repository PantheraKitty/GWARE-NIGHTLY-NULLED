package meteordevelopment.meteorclient.mixininterface;

public interface IChatHudLineVisible extends IChatHudLine {
   boolean meteor$isStartOfEntry();

   void meteor$setStartOfEntry(boolean var1);
}
