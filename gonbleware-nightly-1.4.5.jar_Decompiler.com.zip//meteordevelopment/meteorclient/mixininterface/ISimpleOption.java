package meteordevelopment.meteorclient.mixininterface;

public interface ISimpleOption {
   void set(Object var1);
}
