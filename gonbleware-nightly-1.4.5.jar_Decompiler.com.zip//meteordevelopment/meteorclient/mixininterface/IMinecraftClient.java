package meteordevelopment.meteorclient.mixininterface;

public interface IMinecraftClient {
   void meteor_client$rightClick();
}
