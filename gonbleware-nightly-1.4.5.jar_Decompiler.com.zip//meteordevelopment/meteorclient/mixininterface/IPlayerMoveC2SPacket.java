package meteordevelopment.meteorclient.mixininterface;

public interface IPlayerMoveC2SPacket {
   int getTag();

   void setTag(int var1);
}
