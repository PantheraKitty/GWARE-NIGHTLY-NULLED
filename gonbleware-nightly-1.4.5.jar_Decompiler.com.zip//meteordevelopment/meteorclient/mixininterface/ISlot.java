package meteordevelopment.meteorclient.mixininterface;

public interface ISlot {
   int getId();

   int getIndex();
}
