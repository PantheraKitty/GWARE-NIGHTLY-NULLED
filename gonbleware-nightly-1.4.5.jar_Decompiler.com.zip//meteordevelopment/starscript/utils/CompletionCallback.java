package meteordevelopment.starscript.utils;

public interface CompletionCallback {
   void onCompletion(String var1, boolean var2);
}
