package io.netty.handler.codec.socksx.v5;

import io.netty.handler.codec.socksx.SocksMessage;

public interface Socks5Message extends SocksMessage {
}
