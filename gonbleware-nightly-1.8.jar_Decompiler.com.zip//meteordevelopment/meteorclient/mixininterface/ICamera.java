package meteordevelopment.meteorclient.mixininterface;

public interface ICamera {
   void setRot(double var1, double var3);
}
