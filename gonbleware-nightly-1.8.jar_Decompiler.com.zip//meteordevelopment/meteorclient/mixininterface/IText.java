package meteordevelopment.meteorclient.mixininterface;

public interface IText {
   void meteor$invalidateCache();
}
