package meteordevelopment.meteorclient.mixininterface;

public interface ICapabilityTracker {
   boolean get();

   void set(boolean var1);
}
