package meteordevelopment.meteorclient.mixininterface;

import net.minecraft.class_2561;

public interface IChatHud {
   void meteor$add(class_2561 var1, int var2);
}
