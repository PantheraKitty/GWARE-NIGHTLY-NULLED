package meteordevelopment.meteorclient.mixininterface;

public interface IClientPlayerInteractionManager {
   void meteor$syncSelected();
}
