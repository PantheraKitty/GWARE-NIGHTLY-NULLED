package meteordevelopment.meteorclient.mixininterface;

public interface IHorseBaseEntity {
   void setSaddled(boolean var1);
}
