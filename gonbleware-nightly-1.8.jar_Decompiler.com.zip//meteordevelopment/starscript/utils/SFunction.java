package meteordevelopment.starscript.utils;

import meteordevelopment.starscript.Starscript;
import meteordevelopment.starscript.value.Value;

public interface SFunction {
   Value run(Starscript var1, int var2);
}
