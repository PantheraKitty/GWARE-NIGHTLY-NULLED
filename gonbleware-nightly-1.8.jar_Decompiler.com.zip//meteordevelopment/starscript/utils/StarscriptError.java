package meteordevelopment.starscript.utils;

public class StarscriptError extends RuntimeException {
   public StarscriptError(String message) {
      super(message);
   }
}
